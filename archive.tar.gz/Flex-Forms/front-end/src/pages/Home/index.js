export { HomeContainer as default } from "./HomeContainer";
export { Terms } from "./Terms";
export { Privacy } from "./Privacy";
